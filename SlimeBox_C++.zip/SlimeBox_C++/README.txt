Yareli Marlen Villalobos García
160731

Teoría Computacional

Nombre del Videojuego: SlimeBox
Lenguaje utilizado: C++ junto con SDL2

Indicaciones de instalación:
El proyecto se puede correr en visual studio
*Es posible que sea necesario agregar referencias a las librerias de SDL2
para hacerlo seguir los pasos del siguiente video: 
https://www.youtube.com/watch?v=QQzAHcojEKg&list=PLhfAbcv9cehhkG7ZQK0nfIGJC_C-wSLrx&index=1

configuracion de referencias para las librerias adicionales de imagenes:
https://www.youtube.com/watch?v=YrWQsuDT3NE&list=PLhfAbcv9cehhkG7ZQK0nfIGJC_C-wSLrx&index=4


Descripción: 
El juego consiste en perseguir la caja cerrada,
ésta se mueve de posicion en un tiempo relativamente corto
cada que se toca la caja, el jugador gana un punto 

Existen cajas abiertas que se mueven de igual forma, el jugador tiene que
esquivarlas o de lo contrario perderá

¿Tienes los reflejos suficientes?
¿Cuantos puntos puedes alcanzar antes de que te toque alguna caja abierta?
